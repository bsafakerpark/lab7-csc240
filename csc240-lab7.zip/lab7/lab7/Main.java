package lab7;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        Scanner scanner = new Scanner(System.in);

		        while (true) {
		            System.out.println("Enter a monetary amount (or type 'quit' to exit):");

		            String input = scanner.nextLine().trim();

		            // Exit condition
		            if (input.equalsIgnoreCase("quit")) {
		                break;
		            }

		            try {
		                //Parse the input as a double
		                double amount = Double.parseDouble(input);

		                if (amount < 0) {
		                    System.out.println("Amount can't be negative.Please, enter a valid amount.");
		                    continue;
		                }

		                // Call the method
		                Moneyv2.getMoney(amount); //Use moneyv2 for moneyv2 class

		            } catch (NumberFormatException e) {
		                // Handle invalid input (non-numeric strings)
		                System.out.println("EXCEPTION: Invalid input");
		            }
		        }

		        scanner.close();
		        System.out.println("Quitted.");
		    }
		}

	

