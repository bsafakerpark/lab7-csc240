package lab7;

public class Moneyv2 {
	
	public static void getMoney(double amount) {
        //int dollars = (int) amount; 
        int money = (int) (amount * 100); 
        
        // Denominations for bills and coins
        int[] denom = {1000, 500, 100, 25, 10, 5, 1};
        //int[] coins = {};
        
        int count[] = new int[7];
        
        System.out.println("Money:");
        
        // Calculate bills
        for (int i = 0; i < 7; i++) {
            count[i] = money / denom[i];
            money %= denom[i];
            if (denom[i] == 1000) {
                System.out.println(count[i] + " ten dollar bills");
            } else if (denom[i] == 500) {
                System.out.println(count[i] + " five dollar bills");
            } else if (denom[i] == 100) {
                System.out.println(count[i] + " one dollar bills");
            } else if (denom[i] == 25) {
                System.out.println(count[i] + " quarters");
            } else if (denom[i] == 10) {
                System.out.println(count[i] + " dimes");
            } else if (denom[i] == 5) {
                System.out.println(count[i] + " nickels");
            } else if (denom[i] == 1) {
                System.out.println(count[i] + " pennies");
            }
        }

    }
}

